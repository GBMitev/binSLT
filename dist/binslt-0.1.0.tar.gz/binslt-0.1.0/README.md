To install:

pip install -e path/to/StatisticalLifetimes/
